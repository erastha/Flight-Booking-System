﻿using Flight_booking_System.Model;

namespace Flight_booking_System.Repository
{
    public interface IAdminInterface
    {
        Admin Authenticate(string phoneNo, string password);
    }
}
