﻿namespace Flight_booking_System.Repository
{
    public interface IEmailInterface
    {
        public void SendEmail(string toEmail, string subject, string body);
    }
}
