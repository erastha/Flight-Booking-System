﻿using Microsoft.EntityFrameworkCore;

namespace Flight_booking_System.Model
{
    public class FlightContext:DbContext
    {
        public FlightContext(DbContextOptions<FlightContext> options) : base(options) { }

        public DbSet<User> User2 { get; set; }
        public DbSet<Flight> Flights { get; set; }
        public DbSet<Booking> Trip { get; set; }

    }
}
