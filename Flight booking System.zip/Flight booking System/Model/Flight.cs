﻿using System.ComponentModel.DataAnnotations;

namespace Flight_booking_System.Model
{
    public class Flight
    {
            [Key]
            public int Flight_Id { get; set; }
            [Required(ErrorMessage = "Please enter AirLine_Name")]
            public string AirLine_Name { get; set; }
            [Required(ErrorMessage = "Please enter Departure City")]
            public string Departure_City { get; set; }
            [Required(ErrorMessage = "Please enter Arrival City")]
            public string Arrival_City { get; set; }
            [Required(ErrorMessage = "Please enter Departure Time and Date")]
            [DataType(DataType.DateTime)]
            public DateTime Date_Time { get; set; }
            [Required(ErrorMessage = "Please enter Flight Fare")]
            public int Fare { get; set; }
            [Required(ErrorMessage = "Please enter Available Seats")]
            [Range(1, 40)]
            public int Seat_Available { get; set; }
            [Required(ErrorMessage = "Please enter the class")]
            public string Class { get; set; }
        }

        public class FlightSearch
        {
            [Required(ErrorMessage = "Please select a departure city")]
            public string Departure_City { get; set; }
            [Required(ErrorMessage = "Please select a arrival city")]
            public string Arrival_City { get; set; }
            [Required(ErrorMessage = "Please select travel date")]
            [DataType(DataType.DateTime)]
            public DateTime Date_Time { get; set; }
            [Required(ErrorMessage = "Please select number of travellers")]
            public int NoOfSeats { get; set; }
            [Required(ErrorMessage = "Please select class")]
            public string Class { get; set; }
        }
}
